// pages/movie/movie.js
let user=wx.getStorageSync('user')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    hotshowing: [],
    waitShowArr: [],
    httpLink: "http://127.0.0.1:3000/imgs/",
    showFlag: true ,//电影界面，点击热映和待映
    miz:"59f7d5039423a296f0dbf76e"
  },
  //点击切换热映和待映
  showMode(e) {
    if (e.target.dataset.mode == "热映") {
      this.setData({
        showFlag: true
      })
    } else {
      this.setData({
        showFlag: false
      })
      wx.request({
        url: 'http://127.0.0.1:3000/presell/find',
        success: function (res) {
          this.data.waitShowArr = res.data;
          for (let i = 0; i < res.data.length; i++) {
            this.data.waitShowArr[i].coverphoto[0] = res.data[i].coverphoto[0].substring(5, )
            if (this.data.waitShowArr[i].movietype == "3D") {
              this.data.waitShowArr[i].movietype = true;
            } else {
              this.data.waitShowArr[i].movietype = false;
            }
            if (this.data.waitShowArr[i].peoples< 500) {
              this.data.waitShowArr[i].actor = false;
            } else {
              this.data.waitShowArr[i].actor = true;
            }
          }
          this.setData({
            waitShowArr: this.data.waitShowArr
          })
        }.bind(this)
      })
    }
  },

  //  生命周期函数--监听页面加载

  onLoad: function (options) {
    wx.request({
      url: 'http://127.0.0.1:3000/hotshowing/find', 
      success: function (res) {
        this.data.hotshowing = res.data;
        for (let i = 0; i < res.data.length;i++){
          this.data.hotshowing[i].coverphoto[0] = res.data[i].coverphoto[0].substring(5,)
          if(this.data.hotshowing[i].movietype=="3D"){
            this.data.hotshowing[i].movietype = true;
          }else{
            this.data.hotshowing[i].movietype = false;
          }
          if (this.data.hotshowing[i].score =="暂无评"){
            this.data.hotshowing[i].time=false;
          }else{
            this.data.hotshowing[i].time = true;
          }
        }
        this.data.hotshowing.sort((a,b) => {
          return b.favor - a.favor
        })
        this.setData({
          hotshowing: this.data.hotshowing
        })
      }.bind(this)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})