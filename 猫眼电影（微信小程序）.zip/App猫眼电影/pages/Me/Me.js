//logs.js
const util = require('../../utils/util.js')

Page({
  data: {
    logs: []
  },
  onLoad: function () {
    this.setData({
      logs: (wx.getStorageSync('logs') || []).map(log => {
        return util.formatTime(new Date(log))
      })
    })
  },
  asdf(){
    wx.request({
      url:"http://127.0.0.1:3000/movie/find",
      data:{
        b:1
      },
      success(res){
        wx.setStorageSync('keys', res.data)
        wx.navigateTo({
          url:'../wantToSee/wantToSee'
        })
      }
    })
  },
})
