// pages/Tickets/Tickets.js
let user = wx.getStorageSync('user')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    httpLink: "http://127.0.0.1:3000/",
    hall:{},
    states:[],
    zuos:[],
    zuo:0,
    ids:'',
    name: '',
    img: '',
    cName: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let _this = this
    //标题
    wx.setNavigationBarTitle({
      title: options.text
    })

    _this.data.name = options.name
    _this.setData({
      name: _this.data.name
    })
    wx.request({
      url: `${this.data.httpLink}hallmatch/find`,
      data: {
        _id: options.id
      },
      success: function (data) {
        wx.request({
          url: `${_this.data.httpLink}movie/find`,
          data: {
            _id: data.data.movie
          },
          success: function (res) {
            _this.setData({
              img: res.data.coverphoto[0].replace(/\\/g, "/"),
              cName: res.data.cName
            })
          }
        })
        let halls = data.data
        let time = new Date(data.data.time);
        let times = time.getFullYear() + '-' + (time.getMonth() + 1) + '-' + time.getDate()
        let hours = time.getHours() + ':' + time.getMinutes()
        console.log(times, hours)
        halls.times = times;
        halls.hours = hours;
        _this.setData({
          hall: halls,
          states: halls.seatstate,
          ids: options.id
        })
      }
    })
  },
  add(e){
      let a = e.currentTarget.dataset.row;
      let b = e.currentTarget.dataset.rows;
      let arrState = this.data.states;
      console.log(arrState[a][b])
      let arr = this.data.zuos;
      if (arrState[a][b]) {
        arrState[a][b] = 0;
        for (let i = 0; i < arr.length; i++) {
          if (arr[i][0] == a && arr[i][1] == b) {
            arr.splice(i, 1)
          }
        }
      } else {

        if (this.data.zuo < 4) {
          arrState[a][b] = 1;
          arr.push([a, b]);
        }
      }
      // console.log(arr, arrState[a][b], arrState)
      this.setData({
        states: arrState,
        zuos: arr,
        zuo: arr.length
      })
  },
  mai(){
    let arrs = JSON.stringify(this.data.zuos)
    let arr = this.data.states.map((it) => {
      return it.map((item) => {
        if (item) {
          item = 2;
        }
        return item
      })
    })
    arr = JSON.stringify(arr)
    let _this = this;
    let time = new Date()
    wx.request({
      url: `${_this.data.httpLink}hallmatch/update`,
      data: {
        _id: this.data.ids,
        seatstate: arr
      },
      success: function (data) {
        wx.request({
          url: `${_this.data.httpLink}tickets/add`,
          data: {
            user: user,
            videohall: _this.data.ids,
            seat: arrs,
            time: time,
            name: _this.data.name,
            movie: _this.data.img,
            cName: _this.data.cName,
            money: _this.data.zuo * _this.data.hall.price
          },
          success: function (datas) {
            wx.navigateTo({
              url: "/pages/meIndent/meIndent"
            })
          }
        })
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})