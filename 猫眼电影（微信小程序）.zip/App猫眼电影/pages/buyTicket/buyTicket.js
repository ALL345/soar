// pages/buyTicket/buyTicket.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    checkClick:1,
    httpLink:'http://127.0.0.1:3000/',
    cinema:[]//影院
  },
  clickEvent(e){
    if (e.target.dataset.mode=='1') {
      this.setData({
        checkClick: 1
      })
    } else if (e.target.dataset.mode == '2'){
      this.setData({
        checkClick: 2
      })
    } else if (e.target.dataset.mode == '3'){
      this.setData({
        checkClick: 3
      })
    }else{
      this.setData({
        checkClick: 4
      })
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    //改标题
    wx.setNavigationBarTitle({
      title: options.text
    })
   //查找影院
    wx.request({
      url: `${this.data.httpLink}cinemamatch/find`,
      data: {
        movie: options.id
      },
      success: function (res) {
        let data = [];
        for (let i = 0; i < res.data[0].cinema.length; i++) {
          wx.request({
            url: 'http://127.0.0.1:3000/cinema/find',
            data: {
              _id: res.data[0].cinema[i],
            },
            success(item){
              data.push(item.data)
            }
          })
        }
        //查找影院出现异步操作
        setTimeout(function () {
            for(let i=0;i<data.length;i++){
              for (let j = i + 1;j<data.length;j++){
                if (data[i]._id == data[j]._id){
                     data.splice(j, 1)
                    j--
                  }
              }
            }
         this.data.cinema=data;
         for (let i of this.data.cinema) {
           i.snack = i.snack.split(",");
           i.state = i.state.split(",");
         }
         this.setData({
           cinema: this.data.cinema
         })
        }.bind(this), 500)
      }.bind(this)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})