let user = wx.getStorageSync('user')
Page({
  data: {
    opposiitte:{},
    figure:[],
    stagePhoto:[],
    ifcheck:true,
    httpLinks: "http://127.0.0.1:3000/",
    httpLink: "http://127.0.0.1:3000/imgs/",
    ptext:"",
    pname:"",
    isdianp:"",
    wenzi:"",
    commentId:"",
    wantMovies: [],//想看的电影集合
    num: 0,//用于判断想看时候的状态
    wantHTML: '想看',
  },
  ifcheck(){
    if (this.data.ifcheck){
      this.setData({
        ifcheck: false
      })
    }else{
      this.setData({
        ifcheck: true
      })
    }
  },
  xiangkan(e){
    console.log(this.data.opposiitte)
    if (this.data.opposiitte.b == 0) {
      wx.request({
        url: `${this.data.httpLinks}movie/update`,
        data: {
          _id: this.data.opposiitte._id,
          b: '1'
        },
        success: function (data) {
        }
      })
      this.data.opposiitte.b = 1;
      this.setData({
        opposiitte: this.data.opposiitte
      })

    } else {
      wx.request({
        url: `${this.data.httpLinks}movie/update`,
        data: {
          _id: this.data.opposiitte._id,
          b: '0'
        },
        success: function (data) {
          console.log(data.data)
        }
      })
      this.data.opposiitte.b = 0;
      this.setData({
        
        opposiitte: this.data.opposiitte
      })
    }
  },
  pingfen(){
    if (user){
      wx.navigateTo({
        url: `/pages/shortReview/shortReview?user=${user}&&ptext=${this.data.ptext}&&pname=${this.data.pname}&&wenzi=${this.data.wenzi}&&movieId=${this.data.opposiitte._id}&&commentId=${this.data.commentId}`
      })
    }else{
      wx.navigateTo({
        url:"/pages/log/log"
      })
    }
  },
  onLoad: function (options) {
    let thiss=this;
    wx.request({
      url: 'http://127.0.0.1:3000/comment/find',
      data:{
        userId: user
      },
      success(res){
        for(let i=0;i<res.data.length;i++){
          if (options.id == res.data[i].movieId){
            thiss.data.ptext = res.data[i].text;
            thiss.data.pname = res.data[i].score;
            thiss.data.wenzi = res.data[i].discuss;
            thiss.data.commentId=res.data[i]._id
            thiss.data.isdianp = { 
              discuss: res.data[i].discuss, 
              score: res.data[i].score,
              text: res.data[i].text
              }
              thiss.setData({
                isdianp:thiss.data.isdianp,
                ptext:thiss.data.ptext,
                pname:thiss.data.pname,
                wenzi: thiss.data.wenzi,
                commentId: thiss.data.commentId
              })
            }
        }
      }
    })
    wx.request({
      url: 'http://127.0.0.1:3000/movie/find',
      data: {
        _id: options.id,
      },
      header: {
        'content-type': 'application/json' // 默认值
      },
      success: function (res) {
        this.data.opposiitte = res.data;
        if (this.data.opposiitte.score=='暂无评'){
          this.data.opposiitte.a=false;
        }else{
          this.data.opposiitte.a = true;
        }
        let actor = this.data.opposiitte.actor[1].split(",");
        actor.unshift(this.data.opposiitte.actor[0]);
        let figure = JSON.parse(this.data.opposiitte.actor[2]);
        if (figure.length < actor.length){
             for (let i = 0; i < actor.length;i++){
              let figures ;
              if (actor[i] == actor[i + 1]){
                console.log("2")
                figures = figure[i].substring(5, );
              }else{
                figures = figure[i-1].substring(5, )
                console.log("3")
              }
              let figureN;
              if(i==0){
                figureN="导演"
              }else{
               figureN = "演员"
              }
              this.data.figure.push({ zactor: actor[i], yzactor: figures, figureTapy: figureN })
            }
        }else{
          for (let i = 0; i < figure.length; i++) {
            let figures=figure[i].substring(5, );
            let figureN;
            if (i == 0) {
              figureN = "导演"
            } else {
              figureN = "演员"
            }
            this.data.figure.push({ zactor: actor[i], yzactor: figures, figureTapy: figureN })
          }
        }
        this.data.opposiitte.coverphoto[0] =res.data.coverphoto[0].substring(5, )
        // 剧照
        for (let i = 0; i < this.data.opposiitte.stagephoto.length;i++){
          this.data.opposiitte.stagephoto[i] = this.data.opposiitte.stagephoto[i].substring(5, )
          if(i<5){
            this.data.stagePhoto.push(this.data.opposiitte.stagephoto[i])
          }
        }
        this.setData({
          stagePhoto: this.data.stagePhoto,
          opposiitte: this.data.opposiitte,
          figure: this.data.figure
        })
      }.bind(this)
    })
  },

  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})