// pages/log/log.js
const HTTP = 'http://127.0.0.1:3000/'
Page({

  /**
   * 页面的初始数据
   */
  data: {
    name:'',
    pwd:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },
  userName(e){
    this.setData({
      name: e.detail.value
    })
  },
  userpwd(e){
    this.setData({
      pwd: e.detail.value
    })
  },
  deng(){
    let _this = this;
    wx.request({
      url: `${HTTP}user/find`,
      data:{
        name:this.data.name,
        pwd:this.data.pwd,
        findType:'exact'
      },
      success: function (data) {
        if (data.data.length==1){
          wx.setStorageSync('user',data.data[0]._id)
          wx.switchTab({
            url:'../Film/Film'
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})