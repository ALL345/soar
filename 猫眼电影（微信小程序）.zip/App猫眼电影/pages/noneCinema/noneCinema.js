// pages/noneCinema/noneCinema.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    httpLink: "http://127.0.0.1:3000/",
    nonecinema:{},
    movies: [],//当前电影院的排了片的电影
    moviesArr: [],//当前电影院的排了片的电影数组
    curMovies: [],//电影院拍片中的当前电影
    a: [],
    cinemaId: "",
    buyMovieId: "",
    current: 0,
    curMovie: {}, //当前电影
    name: '',
    cinema: '',
    address: '',
    movieList: [],
    indexs: '',
    scheule: [],
    length: 0
  },
  test() {
    for (let i = 0; i < this.data.moviesArr.length; i++) {
      if (this.data.moviesArr[i]._id == wx.getStorageSync("movieID")) {
        this.setData({
          current: i
        })
        break;
      }
    }
  }, onShow() {
    this.setData({
      cinemaId: wx.getStorageSync("cinemaId"),
      buyMovieId: wx.getStorageSync("cinemaId")
    })
  },
  //电影发生改变的时候
  changeMovie(e) {
    let scheuleTime = [];
    console.log(this.data.moviesArr[e.detail.current])
    let that = this;
    if (this.data.moviesArr[e.detail.current]) {
      let id = this.data.moviesArr[e.detail.current]._id
      wx.request({
        url: `${this.data.httpLink}hallmatch/find`,
        data: {
          movie: id
        },
        success: function (data) {
          data.data.sort((a, b) => {
            return new Date(a.time).getTime() - new Date(b.time).getTime()
          })
          for (let user of data.data) {
            user.time = new Date(user.time).getHours() + ':' + new Date(user.time).getMinutes()
          }
          if (data.data.length > 0) {
            that.data.length = data.data.length
            that.setData({
              scheule: data.data,
              length: data.data.length
            })
          } else {
            that.setData({
              length: 0
            })
          }

        }
      })
    }
    this.setData({
      curMovie: this.data.moviesArr[e.detail.current],
      curMovieIndex: e.detail.current
    })

  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // console.log(options, wx.getStorageSync("movieID"))
    this.setData({
      length: 2,
      cinemaId: wx.getStorageSync("cinemaId"),
      buyMovieId: wx.getStorageSync("buyMovieId"),
      movieID: wx.getStorageSync("movieID")
    })




 //头部  （影院名及地址）
    wx.request({
      url: `${this.data.httpLink}cinema/find`,
      data: {
        _id: options.CinemaId,
      },
      success: function (res) {
        this.data.nonecinema = res.data;
        this.setData({
          nonecinema: this.data.nonecinema
        })
      }.bind(this)
    })
  //滑动
    wx.request({
      url: `${this.data.httpLink}hallmatch/find`,
      data: {
        cinema: options.CinemaId,
      },
      success: function (res) {
        // console.log(res.data)
        for (let item of res.data) {
          this.data.movies.push(item.movie)
        }
        //去除相同的电影的id
        for (let i = 0; i < this.data.movies.length; i++) {
          for (let j = i + 1; j < this.data.movies.length; j++) {
            if (this.data.movies[i] == this.data.movies[j]) {
              this.data.movies.splice(j, 1)
                 j--
            }
          }
        }
        for (let k = 0; k < this.data.movies.length; k++) {
          wx.request({
            url: `${this.data.httpLink}movie/find`,
            data: {
              _id: this.data.movies[k]
            },
            success: function (data) {
              this.data.moviesArr.push(data.data)
              //封面图
              data.data.coverphoto[0] = data.data.coverphoto[0].replace(/\\/, '/')
              this.setData({
                moviesArr: this.data.moviesArr,
                curMovie: this.data.moviesArr[0]
              })
              //定位电影位子
             // 将 data 存储在本地缓存中指定的 key 中，会覆盖掉原来该 key 对应的内容，这是一个同步接口。
              if (data.data._id == wx.getStorageSync("movieID")) {
                this.setData({
                  current: k
                })
              }


            }.bind(this)
          })
        }
      }.bind(this)
    })
    setTimeout(function () {
      let thiss=this;
      wx.request({
        url: `${this.data.httpLink}hallmatch/find`,
        data: {
          movie: this.data.moviesArr[0]._id
        },
        success(res){
          res.data.sort((a, b) => {
            return new Date(a.time).getTime() - new Date(b.time).getTime()
          })
          for (let user of res.data) {
            user.time = new Date(user.time).getHours() + ':' + new Date(user.time).getMinutes()
          }
          console.log(res.data)
          if (res.data.length > 0) {
            thiss.data.length = res.data.length
            thiss.setData({
              scheule: res.data,
              length: res.data.length
            })
          } else {
            thiss.setData({
              length: 0
            })
          }
      }
    })
      this.test()
    }.bind(this), 500)
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})