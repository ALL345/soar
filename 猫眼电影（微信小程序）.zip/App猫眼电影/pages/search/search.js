// pages/search/search.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
      hotSearch:[],
      input:'',
      movie:[],
      httpLink: "http://127.0.0.1:3000/imgs/",
      film:[]
  },
  bindinput(e){
    this.data.input=e.detail.value;
    if(this.data.input.length>0){
      // 搜索电影
      wx.request({
        url: 'http://127.0.0.1:3000/movie/find',
        data: {
          cName: this.data.input
        },
        success: function (res) {
          this.data.movie=res.data
          for (let i = 0; i < res.data.length; i++) {
            this.data.movie[i].actor=this.data.movie[i].actor[1]
            this.data.movie[i].coverphoto[0] = res.data[i].coverphoto[0].substring(5, )
            if (this.data.movie[i].movietype == "3D") {
              this.data.movie[i].movietype = true;
            } else {
              this.data.movie[i].movietype = false;
            }
            if (this.data.movie[i].score == "暂无评") {
              this.data.movie[i].time = false;
            } else {
              this.data.movie[i].time = true;
            }
          }
          this.setData({
            input: this.data.input,
            movie: this.data.movie,
            film: this.data.film
          })
        }.bind(this)
      })
      // 搜索电影院
      wx.request({
        url: 'http://127.0.0.1:3000/cinema/find',
        data: {
          name: this.data.input
        },
        success: function (res) {
          this.data.film = res.data
          for (let i of this.data.film) {
            i.snack = i.snack.split(",");
            i.state = i.state.split(",");
          }
          this.setData({
            input: this.data.input,
            movie: this.data.movie,
            film: this.data.film
          })
        }.bind(this)
      })
    }else{
      this.setData({
        input: this.data.input
      })
      this.data.movie = [];
      this.data.film = [];
    }
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    wx.request({
      url: 'http://127.0.0.1:3000/movie/find',
      success: function (res) {
        
        for (let i = (res.data.length+5);res.data.length<=i;i--){
          this.data.hotSearch.push(res.data[i - (res.data.length)])
        }
        this.setData({
          hotSearch: this.data.hotSearch
        })
      }.bind(this)
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})