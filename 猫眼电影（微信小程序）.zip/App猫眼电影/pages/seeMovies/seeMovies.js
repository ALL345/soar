// pages/seeMovies/seeMovies.js
let user = wx.getStorageSync('user')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    movie:[],
    httpLink: "http://127.0.0.1:3000/imgs/",
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let thiss=this;
    let arry = [];
    wx.request({
      url: 'http://127.0.0.1:3000/comment/find',
      success: function (res) {
          for(let i=0;i<res.data.length;i++){
            if (res.data[i].userId==user){
                  wx.request({
                    url: 'http://127.0.0.1:3000/movie/find',
                    data:{
                      _id: res.data[i].movieId
                    },
                    success: function (res) {
                      arry.push(res.data)
                      thiss.data.movie = arry
                      thiss.setData({
                        movie:thiss.data.movie
                      })
                    }
                  })
              }
          }
      }
   })
  setTimeout(function(){
    // console.log(this.data.movie)
    for (let i = 0; i < this.data.movie.length; i++) {
      this.data.movie[i].actor = this.data.movie[i].actor[1]
      this.data.movie[i].coverphoto[0] = this.data.movie[i].coverphoto[0].substring(5, )
      if (this.data.movie[i].movietype == "3D") {
        this.data.movie[i].movietype = true;
      } else {
        this.data.movie[i].movietype = false;
      }
      if (this.data.movie[i].score == "暂无评") {
        this.data.movie[i].time = false;
      } else {
        this.data.movie[i].time = true;
      }
    }
    this.setData({
      movie: this.data.movie
    })
  }.bind(this),400)
   
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})