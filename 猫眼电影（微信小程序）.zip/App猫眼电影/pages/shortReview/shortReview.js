// pages/shortReview/shortReview.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    text:"",//文字
    name:"",//分数
    user:"",//用户id
    dianping:"",//评论
    movieId:"",//对应电影id
    commentId:""
  },
  tijiao(){
    let _this = this
    if(this.data.text!=""){
     wx.request({
        url: 'http://127.0.0.1:3000/comment/find',
        data: {
            movieId: this.data.movieId
        },
        success: function (res) {
          if (res.data.length!=0){
            wx.request({
              url: 'http://127.0.0.1:3000/comment/update',
              data: {
                _id: _this.data.commentId,
                userId: _this.data.user,
                movieId: _this.data.movieId,
                score: _this.data.name,
                text: _this.data.text,
                time:new Date(),
                discuss: _this.data.dianping,
                a:""
              },
              success: function (res) {
                wx.navigateTo({
                  url: `/pages/datails/datails?id=${_this.data.movieId}`
                })
              }
            })
          }else{
              wx.request({
              url: 'http://127.0.0.1:3000/comment/add',
              data: {
                userId: _this.data.user,
                movieId: _this.data.movieId,
                score: _this.data.name,
                text:_this.data.text,
                time:new Date(),
                discuss: _this.data.dianping,
                a:""
              },
              success: function (res) {
                wx.reLaunch({
                  url: `/pages/datails/datails?id=${_this.data.movieId}`
                })
              }
            })
          }
        }
      })
    }
  },
  textarea(e){
    this.data.dianping = e.detail.value
    this.setData({
      dianping: this.data.dianping
    })
  },
  dian(e){
    switch (e.target.dataset.id){
      case "1":
        this.data.text="超烂啊"
        this.data.name="1"
      break;
      case "2":
        this.data.text = "超烂啊"
        this.data.name = "2"
      break;
      case "3":
        this.data.text = "比较差"
        this.data.name = "3"
        break;
      case "4":
        this.data.text = "比较差"
        this.data.name = "4"
        break;
      case "5":
        this.data.text = "一般般"
        this.data.name = "5"
        break;
      case "6":
        this.data.text = "一般般"
        this.data.name = "6"
        break;
      case "7":
        this.data.text = "比较好"
        this.data.name = "7"
        break;
      case "8":
        this.data.text = "比较好"
        this.data.name = "8"
        break;
      case "9":
        this.data.text = "棒极了"
        this.data.name = "9"
        break;
      case "10":
        this.data.text = "完美"
        this.data.name = "10"
        break;
    }
    this.setData({
      name: this.data.name,
      text: this.data.text
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.data.name = options.pname
    this.data.text = options.ptext
    this.data.user = options.user
    this.data.movieId = options.movieId
    this.data.dianping = options.wenzi
    this.data.commentId = options.commentId
    this.setData({
      name: this.data.name,
      text: this.data.text,
      user:this.data.user,
      movieId: this.data.movieId,
      dianping: this.data.dianping,
      commentId: this.data.commentId
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})